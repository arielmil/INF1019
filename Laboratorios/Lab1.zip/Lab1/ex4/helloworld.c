#include <stdio.h>
#include <stdlib.h> // Para exit()

int main(void) {
    printf("Hello, World!\n");
    exit(0);
}