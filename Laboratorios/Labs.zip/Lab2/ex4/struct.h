typedef struct m {
    int value;
    int seq;
} M;